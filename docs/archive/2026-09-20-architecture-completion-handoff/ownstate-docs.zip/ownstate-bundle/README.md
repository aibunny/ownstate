# Ownstate

> Open infrastructure for sovereign AI knowledge and institutional cognition.

Ownstate is a sovereign knowledge and agent-context layer for individuals and organizations.

The core idea is simple: **models, agents, vendors, and applications should be replaceable. The knowledge accumulated while using them should belong to the individual or organization.**

Ownstate continuously builds and maintains a durable, permission-aware representation of what an organization knows, what happened, what is currently true, what used to be true, what changed, what decisions were made, why they were made, how systems are architected, who customers/investors/partners/vendors are, what commitments and requirements exist, what artifacts have been exchanged, what failed, what succeeded, what risks remain, and what work is happening now.

Ownstate is not a chatbot, model, vector database, or agent framework. It is the persistent institutional state that humans, models, agents, and agent swarms can use.

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Requirements](docs/REQUIREMENTS.md)
- [Codex implementation prompt](docs/CODEX_IMPLEMENTATION_PROMPT.md)

## Product goals

Ownstate should eventually answer questions such as:

- What is our wallet recovery architecture?
- Why was it designed this way?
- How many legal entities do we operate and in which jurisdictions?
- Which entity contracts with Customer X?
- What did we promise Investor Y?
- Which investors received the latest deck?
- Which customers requested feature X?
- What changed across the company this week?
- What are our biggest unresolved risks?
- What work is blocked and why?

Answers should be current, permission-aware, and grounded in evidence.

## Core architecture

Ownstate distinguishes:

1. **Evidence** — what actually happened.
2. **Entities** — durable identities such as companies, people, projects, products, customers, investors, and artifacts.
3. **Relationships** — how entities connect.
4. **Claims** — atomic assertions that may change over time.
5. **Semantic knowledge** — architecture, rationale, decisions, procedures, failures, requirements, and lessons.
6. **Experience** — high-quality work traces that may later train or adapt a personal model.

```text
Raw Evidence
    ↓
Candidate Knowledge
    ↓
Novelty / Validation / Policy
    ↓
Canonical Knowledge
    ↓
Query / Retrieval
    ↓
Context Compiler
    ↓
Human / Model / Agent
    ↓
New Work
    ↓
Raw Evidence
```

## Product modes

### Personal

Individuals can use existing AI tools while Ownstate preserves knowledge across models and agents.

### Business

Business mode extends the same knowledge core with organization-wide institutional state, fine-grained authorization, model-egress policy, UHP-managed agent execution, future agent swarms, audit, data classification, BYOK, and self-hosted inference.

## Open-source philosophy

Ownstate is designed to run locally, in your own cloud, in a private institutional environment, or as a hosted service. Hosted convenience must not become a hidden dependency.

## Quick start

The target local experience is:

```bash
git clone <your-ownstate-repo>
cd ownstate
cp .env.example .env
docker compose up --build
```

The default local stack should remain minimal and should not require Kubernetes, Terraform, paid model APIs, external managed databases, optional connectors, or external message brokers.

## Configuration

All runtime configuration should come from typed configuration backed by environment variables.

```bash
cp .env.example .env
```

Do not commit `.env` files or secrets.

## Development

Typical native development:

```bash
docker compose up -d postgres
cargo run -p ownstate-api
```

Typical full-container development:

```bash
docker compose up --build
```

## Quality checks

```bash
cargo fmt --check
cargo check --workspace
cargo clippy --workspace --all-targets
cargo test --workspace
```

## Documentation rule

`README.md` must always reflect the current implementation. When a change affects setup, architecture, environment variables, Docker, APIs, MCP, model runtimes, infrastructure, or supported capabilities, update the README and relevant docs in the same change.

Clearly distinguish Implemented, Experimental, and Planned functionality.

## Security

Ownstate assumes all AI output and external content is untrusted. Models may propose; deterministic Rust code controls authorization, policy, canonical writes, tool access, model egress, and data classification.

## License

Choose an explicit open-source license before public release and include a `LICENSE` file.

## Contributing

The repository should remain understandable and runnable without access to private company systems, private repositories, paid AI APIs, production infrastructure, or private credentials. Use fictional examples and fixtures in public documentation and tests.
